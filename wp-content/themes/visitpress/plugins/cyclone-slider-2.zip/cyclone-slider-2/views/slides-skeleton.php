<?php if(!defined('ABSPATH')) die('Direct access denied.'); ?>

<div class="cs-slide-skeleton">
	<?php echo $empty_slide; ?>
</div><!-- end .cs-slide-skeleton -->